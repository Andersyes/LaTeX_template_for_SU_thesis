# TemplateThesis

By N Brett:

This template was adapted from  "PhD Thesis Template | U-Paris " - https://fr.overleaf.com/latex/templates/phd-thesis-template-u-paris/qnqhskjxnsvh 
The front cover, located in Layout_Extras/firstpage.tex was adapted from Lefteris' template.
The preamble has also been adapted for this thesis.

The 'bibliographie.bib' file includes references for the complete document in alphabetical order. 
There is a separate folder containing several files for the chapters, figures, images, appendices, and layout_extras (includes acknowledgements, acronyms, cover page etc.). These are the main sections that need completing and editing.
All of these files can then be included in the 'mythesis.tex' file:

'mythesis.tex' is the main document which is recompiled. Here you can use \input{} or \include{} for the chapters, extra pages, preamble etc. 
Figures and images are added to separate folders and included using the folder path e.g. \includegraphics{Figures/chapter1-2/sample.png}

***** Tips! ******
You can use the command \includeonly{Chapters/chapter1} to recomplie a specific chapter, which is useful when the document becomes heavy. Note, this is only applied to those that are included with \include{}, while files included using \input{} will remain. 
******************


